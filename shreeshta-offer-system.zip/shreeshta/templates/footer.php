<footer class="mt-10 border-t border-gold/40 bg-maroon-dark text-ivory/80 text-xs sm:text-sm">
  <div class="max-w-3xl mx-auto px-5 py-6 text-center space-y-1">
    <p>&copy; <?= date('Y') ?> Shreeshta Family Store, Malleshwaram, Bengaluru. All rights reserved.</p>
    <p>Terms and conditions apply.</p>
  </div>
</footer>
</body>
</html>
