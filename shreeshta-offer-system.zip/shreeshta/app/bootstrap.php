<?php
/**
 * app/bootstrap.php
 * Include this one file at the top of every entry-point script
 * (public/*.php, admin/*.php). It loads config, all services, and
 * ensures the database schema exists.
 */

declare(strict_types=1);

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/Database.php';
require_once __DIR__ . '/Products.php';
require_once __DIR__ . '/Settings.php';
require_once __DIR__ . '/Validation.php';
require_once __DIR__ . '/VoucherService.php';
require_once __DIR__ . '/WhatsAppService.php';
require_once __DIR__ . '/CustomerService.php';
require_once __DIR__ . '/AuthService.php';

// Ensure schema exists (cheap: only creates tables if missing)
Database::migrate();
