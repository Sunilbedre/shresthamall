<?php
/**
 * app/AuthService.php
 * Session-based admin/staff authentication with brute-force lockout.
 */

declare(strict_types=1);

final class AuthService
{
    private const MAX_ATTEMPTS = 5;
    private const LOCKOUT_MINUTES = 15;

    public static function attempt(string $username, string $password): array
    {
        $pdo = Database::connection();
        $stmt = $pdo->prepare("SELECT * FROM admins WHERE username = :u LIMIT 1");
        $stmt->execute(['u' => $username]);
        $admin = $stmt->fetch();

        if (!$admin) {
            // Constant-time-ish: still hash something to avoid trivial timing username enumeration
            password_verify($password, '$2y$10$abcdefghijklmnopqrstuuQeYFvE1c8s0m0m0m0m0m0m0m0m0m0m');
            return ['ok' => false, 'error' => 'INVALID_CREDENTIALS'];
        }

        if (!empty($admin['locked_until']) && strtotime($admin['locked_until']) > time()) {
            return ['ok' => false, 'error' => 'LOCKED', 'locked_until' => $admin['locked_until']];
        }

        if (!password_verify($password, $admin['password_hash'])) {
            $attempts = (int) $admin['failed_attempts'] + 1;
            $lockedUntil = null;
            if ($attempts >= self::MAX_ATTEMPTS) {
                $lockedUntil = date('Y-m-d H:i:s', time() + self::LOCKOUT_MINUTES * 60);
                $attempts = 0;
            }
            $upd = $pdo->prepare("UPDATE admins SET failed_attempts = :a, locked_until = :l WHERE id = :id");
            $upd->execute(['a' => $attempts, 'l' => $lockedUntil, 'id' => $admin['id']]);
            return ['ok' => false, 'error' => $lockedUntil ? 'LOCKED' : 'INVALID_CREDENTIALS'];
        }

        // Success — reset attempts, set session
        $upd = $pdo->prepare("UPDATE admins SET failed_attempts = 0, locked_until = NULL, last_login_at = datetime('now') WHERE id = :id");
        $upd->execute(['id' => $admin['id']]);

        session_regenerate_id(true);
        $_SESSION['admin_id'] = $admin['id'];
        $_SESSION['admin_username'] = $admin['username'];
        $_SESSION['admin_role'] = $admin['role'];

        AuditLog::record($admin['username'], 'LOGIN_SUCCESS', null, $_SERVER['REMOTE_ADDR'] ?? null);

        return ['ok' => true, 'admin' => $admin];
    }

    public static function logout(): void
    {
        if (isset($_SESSION['admin_username'])) {
            AuditLog::record($_SESSION['admin_username'], 'LOGOUT', null, $_SERVER['REMOTE_ADDR'] ?? null);
        }
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
        }
        session_destroy();
    }

    public static function check(): bool
    {
        return !empty($_SESSION['admin_id']);
    }

    public static function requireLogin(): void
    {
        if (!self::check()) {
            redirect('/admin/login.php');
        }
    }

    public static function requireRole(string $role): void
    {
        self::requireLogin();
        if ($role === 'admin' && ($_SESSION['admin_role'] ?? '') !== 'admin') {
            http_response_code(403);
            echo 'Forbidden: admin access required.';
            exit;
        }
    }

    public static function currentUsername(): ?string
    {
        return $_SESSION['admin_username'] ?? null;
    }

    public static function currentRole(): ?string
    {
        return $_SESSION['admin_role'] ?? null;
    }

    public static function isAdmin(): bool
    {
        return self::currentRole() === 'admin';
    }

    /** Simple per-IP rate limiter for login attempts, session based (fine for shared hosting without Redis). */
    public static function rateLimited(string $key, int $maxAttempts, int $windowSeconds): bool
    {
        $now = time();
        $bucket = $_SESSION['rate_' . $key] ?? [];
        $bucket = array_filter($bucket, fn($t) => $t > $now - $windowSeconds);
        if (count($bucket) >= $maxAttempts) {
            $_SESSION['rate_' . $key] = $bucket;
            return true;
        }
        $bucket[] = $now;
        $_SESSION['rate_' . $key] = $bucket;
        return false;
    }
}
