<?php
/**
 * app/Products.php
 * Single source of truth for the offer catalogue, session mapping and
 * (optional) per-product registration limits. Both the frontend form and
 * the backend validation read from this file so they can never drift apart.
 */

declare(strict_types=1);

final class Products
{
    /**
     * key => [ label, session, limit_setting_key ]
     * `key` is what gets stored in customers.selected_product and is what
     * the <select>/radio value in the form must send.
     */
    private const CATALOGUE = [
        'saree' => [
            'label'   => '₹1 Saree',
            'session' => 'morning',
            'limit_key' => 'limit_saree',
        ],
        'kids_tshirt_boys' => [
            'label'   => '₹1 Kids T-Shirt – Boys',
            'session' => 'morning',
            'limit_key' => 'limit_kids_boys',
        ],
        'kids_tshirt_girls' => [
            'label'   => '₹1 Kids T-Shirt – Girls',
            'session' => 'morning',
            'limit_key' => 'limit_kids_girls',
        ],
        'womens_leggings' => [
            'label'   => "₹1 Women's Leggings",
            'session' => 'evening',
            'limit_key' => 'limit_leggings',
        ],
        'womens_kurti' => [
            'label'   => "₹1 Women's Kurti",
            'session' => 'evening',
            'limit_key' => 'limit_kurti',
        ],
        'mens_shirt' => [
            'label'   => "₹1 Men's Shirt",
            'session' => 'evening',
            'limit_key' => 'limit_mens_shirt',
        ],
    ];

    public static function all(): array
    {
        return self::CATALOGUE;
    }

    public static function exists(string $key): bool
    {
        return isset(self::CATALOGUE[$key]);
    }

    public static function label(string $key): ?string
    {
        return self::CATALOGUE[$key]['label'] ?? null;
    }

    public static function sessionFor(string $key): ?string
    {
        return self::CATALOGUE[$key]['session'] ?? null;
    }

    public static function limitKeyFor(string $key): ?string
    {
        return self::CATALOGUE[$key]['limit_key'] ?? null;
    }

    public static function bySession(string $session): array
    {
        return array_filter(self::CATALOGUE, fn($p) => $p['session'] === $session);
    }
}
