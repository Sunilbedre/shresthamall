<?php
/**
 * templates/header.php
 * Shared HTML head + top brand bar for all public-facing pages.
 * Expects an optional $pageTitle variable to be set before including.
 */
$pageTitle = $pageTitle ?? 'Shreeshta Family Store – ₹1 Special Offer';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">
<title><?= e($pageTitle) ?></title>
<meta name="description" content="Register for the Shreeshta Family Store ₹1 Special Offer, Malleshwaram, and get your voucher on WhatsApp.">
<meta name="robots" content="noindex, follow">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700;800&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<script>
  tailwind.config = {
    theme: {
      extend: {
        colors: {
          maroon: { DEFAULT: '#7A0026', dark: '#520018' },
          gold: { DEFAULT: '#D8A83E', light: '#F4D47A' },
          ivory: '#FFF9ED',
        },
        fontFamily: {
          serif: ['"Playfair Display"', 'serif'],
          sans: ['Inter', 'ui-sans-serif', 'system-ui'],
        },
      },
    },
  };
</script>
<style>
  body { font-family: 'Inter', sans-serif; background-color: #FFF9ED; }
  h1, h2, h3, .font-heading { font-family: 'Playfair Display', serif; }
  .gold-border { border: 1.5px solid #D8A83E; }
  .gold-ring:focus { outline: none; box-shadow: 0 0 0 3px rgba(216,168,62,0.35); border-color: #D8A83E; }
</style>
</head>
<body class="min-h-screen text-maroon-dark antialiased">

<header class="bg-maroon text-ivory shadow-md">
  <div class="max-w-3xl mx-auto px-5 py-5 text-center">
    <p class="uppercase tracking-[0.2em] text-gold-light text-xs sm:text-sm font-semibold mb-1">Shreeshta Family Store</p>
    <h1 class="font-heading text-2xl sm:text-3xl font-bold">Malleshwaram, Bengaluru</h1>
  </div>
</header>
