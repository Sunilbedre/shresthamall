<?php
/**
 * app/WhatsAppService.php
 * Sends the voucher via Meta WhatsApp Cloud API using an approved template.
 * Never exposes the access token to the frontend — this file only ever runs
 * server-side.
 */

declare(strict_types=1);

final class WhatsAppService
{
    /**
     * Sends the voucher template message to the customer and logs the attempt.
     * Does not throw on API failure — failure is recorded as a FAILED log row
     * so the registration itself is never lost.
     */
    public static function sendVoucher(array $customer, array $voucher): array
    {
        global $CONFIG;
        $wa = $CONFIG['whatsapp'];
        $pdo = Database::connection();

        $productLabel = Products::label($customer['selected_product']) ?? $customer['selected_product'];
        $sessionLabel = VoucherService::formatSessionLabel($customer['session']);
        $eventDateFormatted = (new DateTimeImmutable($voucher['event_date']))->format('d M Y');

        $storeName   = Settings::get('store_name') . ' – ' . Settings::get('branch_name');
        $mapsLink    = Settings::get('maps_link');
        $contactNum  = Settings::get('contact_number');

        $templateName = $wa['template_name'];

        $components = [[
            'type' => 'body',
            'parameters' => [
                ['type' => 'text', 'text' => $customer['full_name']],
                ['type' => 'text', 'text' => $voucher['voucher_code']],
                ['type' => 'text', 'text' => $productLabel],
                ['type' => 'text', 'text' => $eventDateFormatted],
                ['type' => 'text', 'text' => $sessionLabel],
                ['type' => 'text', 'text' => $storeName],
                ['type' => 'text', 'text' => $mapsLink],
                ['type' => 'text', 'text' => $contactNum],
            ],
        ]];

        $payload = [
            'messaging_product' => 'whatsapp',
            'to' => ltrim($customer['mobile_number'], '+'),
            'type' => 'template',
            'template' => [
                'name' => $templateName,
                'language' => ['code' => 'en'],
                'components' => $components,
            ],
        ];

        // Insert a PENDING log row first so we always have a record even if the HTTP call itself throws.
        $insert = $pdo->prepare("
            INSERT INTO whatsapp_logs (customer_id, voucher_id, template_name, status, created_at)
            VALUES (:customer_id, :voucher_id, :template_name, 'PENDING', datetime('now'))
        ");
        $insert->execute([
            'customer_id'   => $customer['id'],
            'voucher_id'    => $voucher['id'],
            'template_name' => $templateName,
        ]);
        $logId = (int) $pdo->lastInsertId();

        if (empty($wa['access_token']) || empty($wa['phone_number_id'])) {
            self::markLog($logId, 'FAILED', ['error' => 'WhatsApp API credentials not configured'], null);
            return ['ok' => false, 'reason' => 'not_configured'];
        }

        $url = "https://graph.facebook.com/{$wa['api_version']}/{$wa['phone_number_id']}/messages";

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_HTTPHEADER => [
                'Authorization: Bearer ' . $wa['access_token'],
                'Content-Type: application/json',
            ],
            CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE),
            CURLOPT_TIMEOUT => 15,
        ]);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);

        if ($response === false) {
            self::markLog($logId, 'FAILED', ['curl_error' => $curlError], null);
            return ['ok' => false, 'reason' => 'network_error'];
        }

        $decoded = json_decode($response, true);

        if ($httpCode >= 200 && $httpCode < 300 && isset($decoded['messages'][0]['id'])) {
            $messageId = $decoded['messages'][0]['id'];
            self::markLog($logId, 'SENT', $decoded, $messageId);
            return ['ok' => true, 'message_id' => $messageId];
        }

        self::markLog($logId, 'FAILED', $decoded ?? ['raw' => $response], null);
        return ['ok' => false, 'reason' => 'api_error', 'detail' => $decoded];
    }

    private static function markLog(int $logId, string $status, ?array $apiResponse, ?string $messageId): void
    {
        $pdo = Database::connection();
        $stmt = $pdo->prepare("
            UPDATE whatsapp_logs
            SET status = :status,
                api_response = :api_response,
                message_id = COALESCE(:message_id, message_id),
                sent_at = CASE WHEN :status2 = 'SENT' THEN datetime('now') ELSE sent_at END,
                failed_at = CASE WHEN :status3 = 'FAILED' THEN datetime('now') ELSE failed_at END
            WHERE id = :id
        ");
        $stmt->execute([
            'status' => $status,
            'api_response' => $apiResponse ? json_encode($apiResponse, JSON_UNESCAPED_UNICODE) : null,
            'message_id' => $messageId,
            'status2' => $status,
            'status3' => $status,
            'id' => $logId,
        ]);
    }

    /** Latest WhatsApp log row for a customer, or null. */
    public static function latestLog(int $customerId): ?array
    {
        $pdo = Database::connection();
        $stmt = $pdo->prepare("SELECT * FROM whatsapp_logs WHERE customer_id = :cid ORDER BY id DESC LIMIT 1");
        $stmt->execute(['cid' => $customerId]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    /** How many resend attempts have happened today for this customer. */
    public static function resendsToday(int $customerId): int
    {
        $pdo = Database::connection();
        $stmt = $pdo->prepare("
            SELECT COUNT(*) FROM whatsapp_logs
            WHERE customer_id = :cid AND date(created_at) = date('now')
        ");
        $stmt->execute(['cid' => $customerId]);
        return (int) $stmt->fetchColumn();
    }

    /** Applies webhook delivery-status updates (delivered/read/failed) by message_id. */
    public static function applyStatusUpdate(string $messageId, string $status): void
    {
        $pdo = Database::connection();
        $column = match ($status) {
            'delivered' => 'delivered_at',
            'read' => 'read_at',
            'failed' => 'failed_at',
            default => null,
        };
        if ($column === null) {
            return;
        }
        $statusUpper = strtoupper($status);
        $stmt = $pdo->prepare("
            UPDATE whatsapp_logs
            SET status = :status, {$column} = datetime('now')
            WHERE message_id = :mid
        ");
        $stmt->execute(['status' => $statusUpper, 'mid' => $messageId]);
    }
}
