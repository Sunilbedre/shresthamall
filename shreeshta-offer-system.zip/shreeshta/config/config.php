<?php
/**
 * config/config.php
 * Loads .env into environment variables and exposes a single $CONFIG array.
 * No external dependencies (no composer) — small hand-rolled .env parser,
 * so this project runs on plain shared hosting with zero `composer install`.
 */

declare(strict_types=1);

// ---- Locate project root -------------------------------------------------
define('APP_ROOT', dirname(__DIR__));

// ---- Minimal .env loader ---------------------------------------------------
function load_env(string $path): void
{
    if (!is_file($path)) {
        return;
    }
    $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        $line = trim($line);
        if ($line === '' || str_starts_with($line, '#')) {
            continue;
        }
        if (!str_contains($line, '=')) {
            continue;
        }
        [$key, $value] = explode('=', $line, 2);
        $key = trim($key);
        $value = trim($value);
        // strip surrounding quotes if present
        if (strlen($value) >= 2 && (
            ($value[0] === '"' && $value[-1] === '"') ||
            ($value[0] === "'" && $value[-1] === "'")
        )) {
            $value = substr($value, 1, -1);
        }
        if (!array_key_exists($key, $_ENV)) {
            putenv("$key=$value");
            $_ENV[$key] = $value;
        }
    }
}

load_env(APP_ROOT . '/.env');

function env(string $key, ?string $default = null): ?string
{
    $value = $_ENV[$key] ?? getenv($key);
    if ($value === false || $value === null || $value === '') {
        return $default;
    }
    return $value;
}

// ---- Timezone ---------------------------------------------------------
date_default_timezone_set(env('APP_TIMEZONE', 'Asia/Kolkata'));

// ---- Global config array ------------------------------------------------
$CONFIG = [
    'app_env'      => env('APP_ENV', 'production'),
    'app_url'      => env('APP_URL', ''),
    'app_secret'   => env('APP_SECRET', 'insecure-default-change-me'),
    'db_path'      => APP_ROOT . '/' . env('DB_PATH', 'storage/database.sqlite'),

    'whatsapp' => [
        'phone_number_id'      => env('WHATSAPP_PHONE_NUMBER_ID', ''),
        'business_account_id'  => env('WHATSAPP_BUSINESS_ACCOUNT_ID', ''),
        'access_token'         => env('WHATSAPP_ACCESS_TOKEN', ''),
        'template_name'        => env('WHATSAPP_TEMPLATE_NAME', 'shreeshta_one_rupee_offer'),
        'api_version'          => env('WHATSAPP_API_VERSION', 'v20.0'),
        'webhook_verify_token' => env('WHATSAPP_WEBHOOK_VERIFY_TOKEN', ''),
    ],

    'turnstile' => [
        'site_key'   => env('TURNSTILE_SITE_KEY', ''),
        'secret_key' => env('TURNSTILE_SECRET_KEY', ''),
    ],
];

// ---- Error display (never show raw errors in production) ---------------
if ($CONFIG['app_env'] === 'production') {
    ini_set('display_errors', '0');
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', '1');
    error_reporting(E_ALL);
}

ini_set('log_errors', '1');
ini_set('error_log', APP_ROOT . '/storage/logs/php-error.log');

// ---- Secure session bootstrap -------------------------------------------
if (session_status() === PHP_SESSION_NONE) {
    $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'domain'   => '',
        'secure'   => $secure,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_name('sfs_session');
    session_start();
}

// ---- CSRF helpers --------------------------------------------------------
function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . htmlspecialchars(csrf_token()) . '">';
}

function csrf_verify(?string $token): bool
{
    if (empty($_SESSION['csrf_token']) || empty($token)) {
        return false;
    }
    return hash_equals($_SESSION['csrf_token'], $token);
}

// ---- Simple helpers -------------------------------------------------------
function e(?string $value): string
{
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

function redirect(string $path): never
{
    header('Location: ' . $path);
    exit;
}

function json_response(array $data, int $status = 200): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
