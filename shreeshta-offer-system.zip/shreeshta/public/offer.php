<?php
/**
 * public/offer.php  ->  route: /offer
 * Single customer-facing landing page + registration form.
 * GET  = show the page
 * POST = process registration (action=register) or resend an existing
 *        voucher (action=resend_existing)
 */

declare(strict_types=1);
require_once __DIR__ . '/../app/bootstrap.php';

$eventDate = Settings::get('event_date');
$eventDateFormatted = $eventDate ? (new DateTimeImmutable($eventDate))->format('d M Y') : '';
$registrationOpen = Settings::get('registration_status', 'OPEN') === 'OPEN';

$morningLabel = VoucherService::formatSessionLabel('morning');
$eveningLabel = VoucherService::formatSessionLabel('evening');

$errors = [];
$duplicateCustomer = null;
$resendMessage = null;
$oldInput = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? 'register';

    if (!csrf_verify($_POST['csrf_token'] ?? null)) {
        $errors['_general'] = 'Your session expired. Please try again.';
    } elseif (AuthService::rateLimited('register_' . ($_SERVER['REMOTE_ADDR'] ?? 'unknown'), 8, 300)) {
        $errors['_general'] = 'Too many attempts. Please wait a few minutes and try again.';
    } elseif ($action === 'resend_existing') {
        $mobile = Validation::normaliseMobile((string) ($_POST['mobile_number'] ?? ''));
        if ($mobile === null) {
            $errors['_general'] = 'Please enter a valid mobile number to resend the voucher.';
        } else {
            $customer = CustomerService::findByMobile($mobile);
            if (!$customer) {
                $errors['_general'] = 'No registration found for this mobile number.';
            } else {
                $maxResends = (int) Settings::get('max_whatsapp_resends', '3');
                if (WhatsAppService::resendsToday((int) $customer['id']) >= $maxResends) {
                    $errors['_general'] = 'Maximum resend attempts reached for today. Please visit the store counter for help.';
                } else {
                    $voucher = VoucherModel::findByCustomerId((int) $customer['id']);
                    if ($voucher) {
                        WhatsAppService::sendVoucher($customer, $voucher);
                        $resendMessage = 'Your voucher has been resent to your WhatsApp number.';
                    }
                }
            }
            $duplicateCustomer = $customer;
        }
    } else {
        $oldInput = $_POST;
        $result = CustomerService::register($_POST, $_SERVER['REMOTE_ADDR'] ?? '', $_SERVER['HTTP_USER_AGENT'] ?? '');

        if ($result['ok']) {
            $_SESSION['last_registration_customer_id'] = $result['customer']['id'];
            WhatsAppService::sendVoucher($result['customer'], $result['voucher']);
            redirect('/success.php');
        }

        switch ($result['error'] ?? '') {
            case CustomerService::ERR_VALIDATION:
                $errors = $result['fields'];
                break;
            case CustomerService::ERR_DUPLICATE_MOBILE:
                $duplicateCustomer = $result['customer'];
                break;
            case CustomerService::ERR_REGISTRATION_CLOSED:
                $errors['_general'] = 'closed';
                break;
            case CustomerService::ERR_PRODUCT_FULL:
                $errors['_general'] = 'Sorry, this offer is fully booked. Please choose another product.';
                break;
            default:
                $errors['_general'] = 'Something went wrong. Please try again.';
        }
    }
}

$pageTitle = 'Shreeshta Family Store – ₹1 Special Offer';
require __DIR__ . '/../templates/header.php';
?>

<main class="max-w-3xl mx-auto px-5 py-8">

  <?php if (!$registrationOpen && empty($duplicateCustomer)): ?>
    <div class="bg-white gold-border rounded-2xl p-8 text-center shadow-sm">
      <h2 class="font-heading text-2xl font-bold text-maroon mb-2">Registrations Are Closed</h2>
      <p class="text-maroon-dark/80">Thank you for your interest in the Shreeshta Family Store ₹1 Special Offer.</p>
    </div>

  <?php else: ?>

    <section class="text-center mb-8">
      <h2 class="font-heading text-3xl sm:text-4xl font-extrabold text-maroon mb-3">₹1 Special Shopping Offer</h2>
      <p class="text-maroon-dark/80 max-w-xl mx-auto">Register now and receive your exclusive ₹1 shopping voucher directly on WhatsApp.</p>
      <?php if ($eventDateFormatted): ?>
        <p class="mt-2 text-sm font-semibold text-gold-light bg-maroon inline-block px-4 py-1 rounded-full"><?= e($eventDateFormatted) ?></p>
      <?php endif; ?>
    </section>

    <div class="bg-maroon text-ivory rounded-2xl px-5 py-4 text-center font-semibold gold-border mb-8 text-sm sm:text-base tracking-wide">
      One Customer &bull; One Mobile Number &bull; One Voucher &bull; One Product
    </div>

    <section class="grid sm:grid-cols-2 gap-5 mb-10">
      <div class="bg-white rounded-2xl gold-border p-5 shadow-sm">
        <h3 class="font-heading text-xl font-bold text-maroon mb-1">Morning Offer</h3>
        <p class="text-gold text-sm font-semibold mb-3"><?= e($morningLabel) ?></p>
        <ul class="space-y-1 text-sm text-maroon-dark/90">
          <?php foreach (Products::bySession('morning') as $p): ?>
            <li class="flex items-center gap-2"><span class="text-gold">&#10003;</span><?= e($p['label']) ?></li>
          <?php endforeach; ?>
        </ul>
      </div>
      <div class="bg-white rounded-2xl gold-border p-5 shadow-sm">
        <h3 class="font-heading text-xl font-bold text-maroon mb-1">Evening Offer</h3>
        <p class="text-gold text-sm font-semibold mb-3"><?= e($eveningLabel) ?></p>
        <ul class="space-y-1 text-sm text-maroon-dark/90">
          <?php foreach (Products::bySession('evening') as $p): ?>
            <li class="flex items-center gap-2"><span class="text-gold">&#10003;</span><?= e($p['label']) ?></li>
          <?php endforeach; ?>
        </ul>
      </div>
    </section>

    <?php if ($duplicateCustomer): ?>
      <section class="bg-white gold-border rounded-2xl p-6 sm:p-8 shadow-sm mb-8">
        <h3 class="font-heading text-xl font-bold text-maroon mb-2">This mobile number has already received a voucher.</h3>
        <p class="text-maroon-dark/80 mb-4 text-sm sm:text-base">Only one voucher is allowed per customer and mobile number. Please check your WhatsApp for the existing voucher.</p>
        <?php if ($resendMessage): ?>
          <p class="text-green-700 bg-green-50 border border-green-200 rounded-lg px-4 py-2 text-sm mb-4"><?= e($resendMessage) ?></p>
        <?php endif; ?>
        <form method="post" class="flex flex-col sm:flex-row gap-3">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="resend_existing">
          <input type="hidden" name="mobile_number" value="<?= e($duplicateCustomer['mobile_number']) ?>">
          <button type="submit" class="bg-gold hover:bg-gold-light transition text-maroon-dark font-bold py-3 px-6 rounded-xl gold-border">
            Resend Existing Voucher
          </button>
        </form>
      </section>
    <?php endif; ?>

    <?php if (!empty($errors['_general']) && $errors['_general'] === 'closed'): ?>
      <div class="bg-white gold-border rounded-2xl p-8 text-center shadow-sm">
        <h2 class="font-heading text-2xl font-bold text-maroon mb-2">Registrations Are Closed</h2>
        <p class="text-maroon-dark/80">Thank you for your interest in the Shreeshta Family Store ₹1 Special Offer.</p>
      </div>
    <?php elseif (!$duplicateCustomer && $registrationOpen): ?>

      <section class="bg-white gold-border rounded-2xl p-5 sm:p-8 shadow-sm">
        <h3 class="font-heading text-2xl font-bold text-maroon mb-5 text-center">Register for Your Voucher</h3>

        <?php if (!empty($errors['_general'])): ?>
          <p class="text-red-700 bg-red-50 border border-red-200 rounded-lg px-4 py-2 text-sm mb-4"><?= e($errors['_general']) ?></p>
        <?php endif; ?>

        <form method="post" class="space-y-5" id="regForm">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="register">

          <div>
            <label for="full_name" class="block font-semibold text-maroon-dark mb-1.5">Full Name</label>
            <input type="text" id="full_name" name="full_name" required minlength="2" maxlength="80"
              value="<?= e($oldInput['full_name'] ?? '') ?>"
              class="w-full rounded-xl gold-border gold-ring px-4 py-3.5 text-base"
              placeholder="Your full name">
            <?php if (!empty($errors['full_name'])): ?><p class="text-red-600 text-sm mt-1"><?= e($errors['full_name']) ?></p><?php endif; ?>
          </div>

          <div>
            <label for="mobile_number" class="block font-semibold text-maroon-dark mb-1.5">WhatsApp Mobile Number</label>
            <div class="flex items-center gold-border rounded-xl overflow-hidden gold-ring focus-within:ring-2">
              <span class="px-3 py-3.5 bg-ivory text-maroon-dark/70 font-semibold border-r border-gold/40">+91</span>
              <input type="tel" id="mobile_number" name="mobile_number" required inputmode="numeric" maxlength="10" pattern="[6-9][0-9]{9}"
                value="<?= e($oldInput['mobile_number'] ?? '') ?>"
                class="flex-1 px-4 py-3.5 text-base outline-none"
                placeholder="10-digit mobile number">
            </div>
            <?php if (!empty($errors['mobile_number'])): ?><p class="text-red-600 text-sm mt-1"><?= e($errors['mobile_number']) ?></p><?php endif; ?>
          </div>

          <div>
            <span class="block font-semibold text-maroon-dark mb-2">Select Your ₹1 Offer</span>

            <p class="text-xs uppercase tracking-wide text-gold font-bold mb-1.5">Morning &middot; <?= e($morningLabel) ?></p>
            <div class="grid gap-2 mb-3">
              <?php foreach (Products::bySession('morning') as $key => $p): ?>
                <label class="flex items-center gap-3 rounded-xl gold-border px-4 py-3 cursor-pointer has-[:checked]:bg-gold-light/40 has-[:checked]:border-gold">
                  <input type="radio" name="selected_offer" value="<?= e($key) ?>" required
                    <?= (($oldInput['selected_offer'] ?? '') === $key) ? 'checked' : '' ?>
                    class="accent-[#7A0026] w-5 h-5">
                  <span class="text-sm sm:text-base"><?= e($p['label']) ?></span>
                </label>
              <?php endforeach; ?>
            </div>

            <p class="text-xs uppercase tracking-wide text-gold font-bold mb-1.5">Evening &middot; <?= e($eveningLabel) ?></p>
            <div class="grid gap-2">
              <?php foreach (Products::bySession('evening') as $key => $p): ?>
                <label class="flex items-center gap-3 rounded-xl gold-border px-4 py-3 cursor-pointer has-[:checked]:bg-gold-light/40 has-[:checked]:border-gold">
                  <input type="radio" name="selected_offer" value="<?= e($key) ?>" required
                    <?= (($oldInput['selected_offer'] ?? '') === $key) ? 'checked' : '' ?>
                    class="accent-[#7A0026] w-5 h-5">
                  <span class="text-sm sm:text-base"><?= e($p['label']) ?></span>
                </label>
              <?php endforeach; ?>
            </div>
            <?php if (!empty($errors['selected_offer'])): ?><p class="text-red-600 text-sm mt-1"><?= e($errors['selected_offer']) ?></p><?php endif; ?>
          </div>

          <div class="flex items-start gap-3">
            <input type="checkbox" id="consent" name="consent" value="1" required
              <?= !empty($oldInput['consent']) ? 'checked' : '' ?>
              class="mt-1 w-5 h-5 accent-[#7A0026]">
            <label for="consent" class="text-sm text-maroon-dark/85">
              I agree to receive my voucher and offer-related communication from Shreeshta Family Store through WhatsApp.
            </label>
          </div>
          <?php if (!empty($errors['consent'])): ?><p class="text-red-600 text-sm -mt-3"><?= e($errors['consent']) ?></p><?php endif; ?>

          <button type="submit"
            class="w-full bg-maroon hover:bg-maroon-dark transition text-ivory font-bold text-lg py-4 rounded-xl gold-border shadow-md">
            Get My ₹1 Voucher on WhatsApp
          </button>
        </form>
      </section>

      <section class="mt-8 bg-white/70 gold-border rounded-2xl p-5 text-xs sm:text-sm text-maroon-dark/75 space-y-1">
        <p class="font-semibold text-maroon-dark mb-1">Terms &amp; Conditions</p>
        <ul class="list-disc list-inside space-y-0.5">
          <li>One customer can avail only one ₹1 product.</li>
          <li>One mobile number is eligible for only one voucher.</li>
          <li>The selected product cannot be changed after registration.</li>
          <li>The voucher is valid only for the mentioned date and time slot.</li>
          <li>The voucher can be redeemed only once.</li>
          <li>The original WhatsApp voucher must be shown at the verification counter.</li>
          <li>The offer is subject to stock availability. Size, colour and design are subject to availability.</li>
          <li>The voucher cannot be exchanged for cash, transferred or duplicated.</li>
          <li>Shreeshta Family Store reserves the right to reject fraudulent or duplicate registrations.</li>
        </ul>
      </section>

    <?php endif; ?>
  <?php endif; ?>
</main>

<script>
  // Strip non-digits as the customer types, client-side UX only — server re-validates everything.
  const mobileInput = document.getElementById('mobile_number');
  if (mobileInput) {
    mobileInput.addEventListener('input', () => {
      mobileInput.value = mobileInput.value.replace(/\D/g, '').slice(0, 10);
    });
  }
</script>

<?php require __DIR__ . '/../templates/footer.php'; ?>
