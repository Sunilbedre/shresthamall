<?php
/** templates/admin_nav.php — expects $activePage to be set (dashboard|registrations|settings|exports) */
$activePage = $activePage ?? '';
$navItems = [
    'dashboard' => ['/admin/dashboard.php', 'Dashboard'],
    'registrations' => ['/admin/registrations.php', 'Registrations'],
];
if (AuthService::isAdmin()) {
    $navItems['exports'] = ['/admin/exports.php', 'Exports'];
    $navItems['settings'] = ['/admin/settings.php', 'Settings'];
}
$navItems['verify'] = ['/verify.php', 'Verify Counter'];
?>
<header class="bg-maroon text-ivory shadow-md">
  <div class="max-w-5xl mx-auto px-5 py-4 flex flex-wrap items-center justify-between gap-3">
    <div>
      <p class="uppercase tracking-widest text-gold-light text-[10px] font-semibold">Shreeshta Family Store</p>
      <h1 class="font-heading text-lg font-bold leading-tight">Admin Panel</h1>
    </div>
    <nav class="flex flex-wrap gap-1.5 text-sm">
      <?php foreach ($navItems as $key => [$url, $label]): ?>
        <a href="<?= e($url) ?>"
          class="px-3 py-1.5 rounded-lg font-semibold transition <?= $activePage === $key ? 'bg-gold text-maroon-dark' : 'hover:bg-maroon-dark' ?>">
          <?= e($label) ?>
        </a>
      <?php endforeach; ?>
      <a href="/admin/logout.php" class="px-3 py-1.5 rounded-lg font-semibold text-gold-light hover:bg-maroon-dark">Logout</a>
    </nav>
  </div>
</header>
