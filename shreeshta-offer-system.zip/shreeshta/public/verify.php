<?php
/**
 * public/verify.php  ->  route: /verify
 * Staff/admin voucher verification + redemption counter tool.
 * Requires login (admin or staff role — see AuthService::requireLogin).
 */

declare(strict_types=1);
require_once __DIR__ . '/../app/bootstrap.php';

AuthService::requireLogin();

$result = null; // ['status' => ..., 'voucher' => ..., 'customer' => ...]
$searchValue = '';
$redeemMessage = null;
$redeemError = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify($_POST['csrf_token'] ?? null)) {
        $redeemError = 'Your session expired. Please search again.';
    } else {
        $action = $_POST['action'] ?? 'search';

        if ($action === 'search') {
            $searchValue = trim((string) ($_POST['query'] ?? ''));
            $voucher = null;

            $asMobile = Validation::normaliseMobile($searchValue);
            if ($asMobile !== null) {
                $customer = CustomerService::findByMobile($asMobile);
                if ($customer) {
                    $voucher = VoucherModel::findByCustomerId((int) $customer['id']);
                }
            }
            if ($voucher === null) {
                $voucher = VoucherModel::findByCode($searchValue);
            }

            if ($voucher) {
                $customer = CustomerService::findById((int) $voucher['customer_id']);
                $status = VoucherService::checkStatus($voucher);
                $result = ['status' => $status, 'voucher' => $voucher, 'customer' => $customer];
            } else {
                $result = ['status' => 'INVALID', 'voucher' => null, 'customer' => null];
            }
        } elseif ($action === 'redeem') {
            $voucherId = (int) ($_POST['voucher_id'] ?? 0);
            $billingRef = trim((string) ($_POST['billing_reference'] ?? '')) ?: null;
            $redeemResult = VoucherModel::redeem($voucherId, AuthService::currentUsername() ?? 'staff', $billingRef);

            if ($redeemResult['ok']) {
                $redeemMessage = 'Voucher Successfully Redeemed';
                $voucher = $redeemResult['voucher'];
                $customer = CustomerService::findById((int) $voucher['customer_id']);
                $result = ['status' => 'ALREADY_REDEEMED', 'voucher' => $voucher, 'customer' => $customer];
            } else {
                $voucher = VoucherModel::findById($voucherId);
                $customer = $voucher ? CustomerService::findById((int) $voucher['customer_id']) : null;
                $status = $voucher ? VoucherService::checkStatus($voucher) : 'INVALID';
                $result = ['status' => $status, 'voucher' => $voucher, 'customer' => $customer];
                $redeemError = 'Could not redeem: ' . str_replace('_', ' ', $redeemResult['error']);
            }
        }
    }
}

$statusStyles = [
    'VALID'            => ['label' => 'Valid Voucher', 'color' => 'green'],
    'NOT_ACTIVE_YET'   => ['label' => 'Voucher Not Active Yet', 'color' => 'yellow'],
    'TIME_EXPIRED'     => ['label' => 'Voucher Time Expired', 'color' => 'red'],
    'ALREADY_REDEEMED' => ['label' => 'Voucher Already Redeemed', 'color' => 'red'],
    'BLOCKED'          => ['label' => 'Voucher Blocked', 'color' => 'red'],
    'CANCELLED'        => ['label' => 'Voucher Cancelled', 'color' => 'red'],
    'INVALID'          => ['label' => 'Coupon Not Found', 'color' => 'gray'],
];

$pageTitle = 'Voucher Verification – Shreeshta Family Store';
require __DIR__ . '/../templates/header.php';
?>

<main class="max-w-2xl mx-auto px-5 py-8">
  <div class="flex items-center justify-between mb-6">
    <h2 class="font-heading text-2xl font-bold text-maroon">Voucher Verification</h2>
    <a href="/admin/logout.php" class="text-sm text-maroon-dark/70 underline">Logout (<?= e(AuthService::currentUsername() ?? '') ?>)</a>
  </div>

  <form method="post" class="bg-white gold-border rounded-2xl p-5 shadow-sm mb-6 flex flex-col sm:flex-row gap-3">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="search">
    <input type="text" name="query" required value="<?= e($searchValue) ?>"
      placeholder="Voucher code (SFS1-XXXXXX) or mobile number"
      class="flex-1 rounded-xl gold-border gold-ring px-4 py-3 text-base">
    <button type="submit" class="bg-maroon hover:bg-maroon-dark transition text-ivory font-bold px-6 py-3 rounded-xl">Search</button>
  </form>

  <?php if ($redeemError): ?>
    <p class="text-red-700 bg-red-50 border border-red-200 rounded-lg px-4 py-2 text-sm mb-4"><?= e($redeemError) ?></p>
  <?php endif; ?>
  <?php if ($redeemMessage): ?>
    <p class="text-green-700 bg-green-50 border border-green-200 rounded-lg px-4 py-2 text-sm mb-4 font-semibold"><?= e($redeemMessage) ?></p>
  <?php endif; ?>

  <?php if ($result): ?>
    <?php
      $style = $statusStyles[$result['status']] ?? $statusStyles['INVALID'];
      $colorClasses = [
        'green'  => 'bg-green-50 border-green-300 text-green-800',
        'yellow' => 'bg-yellow-50 border-yellow-300 text-yellow-800',
        'red'    => 'bg-red-50 border-red-300 text-red-800',
        'gray'   => 'bg-gray-50 border-gray-300 text-gray-700',
      ][$style['color']];
      $voucher = $result['voucher'];
      $customer = $result['customer'];
    ?>
    <div class="rounded-2xl border-2 p-5 sm:p-6 <?= $colorClasses ?>">
      <h3 class="font-heading text-xl font-bold mb-3"><?= e($style['label']) ?></h3>

      <?php if ($customer && $voucher): ?>
        <div class="space-y-2 text-sm sm:text-base mb-4">
          <p><span class="font-semibold">Customer:</span> <?= e($customer['full_name']) ?></p>
          <p><span class="font-semibold">Mobile:</span> <?= e(Validation::maskMobile($customer['mobile_number'])) ?></p>
          <p><span class="font-semibold">Product:</span> <?= e(Products::label($customer['selected_product'])) ?></p>
          <p><span class="font-semibold">Applicable Time:</span> <?= e(VoucherService::formatSessionLabel($customer['session'])) ?></p>
          <p><span class="font-semibold">Voucher Code:</span> <span class="font-mono"><?= e($voucher['voucher_code']) ?></span></p>
          <?php if ($result['status'] === 'ALREADY_REDEEMED' && $voucher['redeemed_at']): ?>
            <p><span class="font-semibold">Redeemed At:</span> <?= e($voucher['redeemed_at']) ?> by <?= e($voucher['redeemed_by'] ?? '-') ?></p>
          <?php endif; ?>
          <?php if ($result['status'] === 'NOT_ACTIVE_YET'): ?>
            <p><span class="font-semibold">Starts At:</span> <?= e((new DateTimeImmutable($voucher['session_start']))->format('d M Y, g:i A')) ?></p>
          <?php endif; ?>
          <?php if ($result['status'] === 'TIME_EXPIRED'): ?>
            <p><span class="font-semibold">Was Valid Until:</span> <?= e((new DateTimeImmutable($voucher['session_end']))->format('d M Y, g:i A')) ?></p>
          <?php endif; ?>
        </div>

        <form method="post" onsubmit="return confirm('Are you sure you want to redeem this voucher for ₹1 <?= e(addslashes(Products::label($customer['selected_product']) ?? '')) ?>?');" class="flex flex-col sm:flex-row gap-3">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="redeem">
          <input type="hidden" name="voucher_id" value="<?= (int) $voucher['id'] ?>">
          <input type="text" name="billing_reference" placeholder="Billing reference (optional)"
            class="flex-1 rounded-xl border border-current/30 px-4 py-2.5 text-sm bg-white/70">
          <button type="submit" <?= $result['status'] !== 'VALID' ? 'disabled' : '' ?>
            class="font-bold px-6 py-2.5 rounded-xl text-sm <?= $result['status'] === 'VALID' ? 'bg-maroon text-ivory hover:bg-maroon-dark' : 'bg-gray-300 text-gray-500 cursor-not-allowed' ?>">
            Redeem Voucher
          </button>
        </form>
      <?php else: ?>
        <p class="text-sm">No registration matches this voucher code or mobile number.</p>
      <?php endif; ?>
    </div>
  <?php endif; ?>
</main>

<?php require __DIR__ . '/../templates/footer.php'; ?>
