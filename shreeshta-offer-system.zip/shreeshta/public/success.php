<?php
/**
 * public/success.php  ->  route: /success
 * Shown right after a successful registration. Reads the customer id from
 * the session (set by offer.php) rather than a URL parameter, so vouchers
 * can't be enumerated by guessing IDs in the address bar.
 */

declare(strict_types=1);
require_once __DIR__ . '/../app/bootstrap.php';

$customerId = $_SESSION['last_registration_customer_id'] ?? null;
$customer = $customerId ? CustomerService::findById((int) $customerId) : null;
$voucher = $customer ? VoucherModel::findByCustomerId((int) $customer['id']) : null;

if (!$customer || !$voucher) {
    redirect('/offer.php');
}

$waLog = WhatsAppService::latestLog((int) $customer['id']);
$waStatus = $waLog['status'] ?? 'PENDING';

$productLabel = Products::label($customer['selected_product']);
$sessionLabel = VoucherService::formatSessionLabel($customer['session']);
$eventDateFormatted = (new DateTimeImmutable($voucher['event_date']))->format('d M Y');
$storeName = Settings::get('store_name') . ' – ' . Settings::get('branch_name');
$mapsLink = Settings::get('maps_link');
$contactNumber = Settings::get('contact_number');

$waNumberDigits = ltrim($customer['mobile_number'], '+');
$waDeepLink = 'https://wa.me/' . $waNumberDigits;
$callLink = 'tel:' . $contactNumber;

$pageTitle = 'Voucher Confirmed – Shreeshta Family Store';
require __DIR__ . '/../templates/header.php';
?>

<main class="max-w-2xl mx-auto px-5 py-8">

  <div class="bg-white gold-border rounded-2xl p-6 sm:p-8 shadow-md text-center">
    <div class="w-16 h-16 rounded-full bg-gold-light mx-auto flex items-center justify-center mb-4">
      <span class="text-3xl text-maroon">&#10003;</span>
    </div>
    <h2 class="font-heading text-2xl sm:text-3xl font-bold text-maroon mb-1">Congratulations!</h2>
    <p class="text-maroon-dark/80 mb-6">Your ₹1 Offer Voucher Is Confirmed</p>

    <div class="bg-ivory gold-border rounded-2xl p-5 text-left space-y-3">
      <div class="flex justify-between border-b border-gold/30 pb-2">
        <span class="text-sm text-maroon-dark/70">Customer Name</span>
        <span class="font-semibold"><?= e($customer['full_name']) ?></span>
      </div>
      <div class="flex justify-between border-b border-gold/30 pb-2">
        <span class="text-sm text-maroon-dark/70">Voucher Code</span>
        <span class="font-mono font-bold text-maroon tracking-wide"><?= e($voucher['voucher_code']) ?></span>
      </div>
      <div class="flex justify-between border-b border-gold/30 pb-2">
        <span class="text-sm text-maroon-dark/70">Selected Product</span>
        <span class="font-semibold text-right"><?= e($productLabel) ?></span>
      </div>
      <div class="flex justify-between border-b border-gold/30 pb-2">
        <span class="text-sm text-maroon-dark/70">Offer Date</span>
        <span class="font-semibold"><?= e($eventDateFormatted) ?></span>
      </div>
      <div class="flex justify-between border-b border-gold/30 pb-2">
        <span class="text-sm text-maroon-dark/70">Applicable Time</span>
        <span class="font-semibold"><?= e($sessionLabel) ?></span>
      </div>
      <div class="flex justify-between border-b border-gold/30 pb-2">
        <span class="text-sm text-maroon-dark/70">Store</span>
        <span class="font-semibold text-right"><?= e($storeName) ?></span>
      </div>
      <div class="flex justify-between items-center">
        <span class="text-sm text-maroon-dark/70">WhatsApp Delivery</span>
        <?php if ($waStatus === 'SENT' || $waStatus === 'DELIVERED' || $waStatus === 'READ'): ?>
          <span class="text-green-700 font-semibold text-sm bg-green-50 border border-green-200 rounded-full px-3 py-0.5">Sent</span>
        <?php elseif ($waStatus === 'FAILED'): ?>
          <span class="text-amber-700 font-semibold text-sm bg-amber-50 border border-amber-200 rounded-full px-3 py-0.5">Pending</span>
        <?php else: ?>
          <span class="text-amber-700 font-semibold text-sm bg-amber-50 border border-amber-200 rounded-full px-3 py-0.5">Pending</span>
        <?php endif; ?>
      </div>
    </div>

    <?php if ($waStatus === 'FAILED'): ?>
      <p class="text-sm text-amber-800 bg-amber-50 border border-amber-200 rounded-xl px-4 py-3 mt-4">
        Your voucher has been generated. WhatsApp delivery is pending.
      </p>
    <?php endif; ?>

    <p class="text-xs sm:text-sm text-maroon-dark/70 mt-5 bg-gold-light/30 rounded-xl px-4 py-3">
      You can avail only the product selected during registration. Product changes are not allowed after voucher generation.
    </p>

    <div class="grid sm:grid-cols-3 gap-3 mt-6">
      <a href="<?= e($waDeepLink) ?>" target="_blank" rel="noopener"
        class="bg-green-600 hover:bg-green-700 transition text-white font-bold py-3 rounded-xl text-sm flex items-center justify-center">
        Open WhatsApp
      </a>
      <a href="<?= e($mapsLink) ?>" target="_blank" rel="noopener"
        class="bg-maroon hover:bg-maroon-dark transition text-ivory font-bold py-3 rounded-xl text-sm flex items-center justify-center">
        Get Directions
      </a>
      <a href="<?= e($callLink) ?>"
        class="bg-gold hover:bg-gold-light transition text-maroon-dark font-bold py-3 rounded-xl text-sm flex items-center justify-center gold-border">
        Call Store
      </a>
    </div>
  </div>
</main>

<?php require __DIR__ . '/../templates/footer.php'; ?>
